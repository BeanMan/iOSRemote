//
//  AppDelegate.m
//  MobilSeverPush
//
//  Created by bean on 2017/1/10.
//  Copyright © 2017年 com.xile. All rights reserved.
//

#import "AppDelegate.h"
#import <AdSupport/AdSupport.h>
@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    
    //注册通知
    if ([UIDevice currentDevice].systemVersion.doubleValue<8.0) {
        [[UIApplication sharedApplication] registerForRemoteNotificationTypes:(UIRemoteNotificationTypeAlert | UIRemoteNotificationTypeSound | UIRemoteNotificationTypeBadge)];
    }
    else {
        [[UIApplication sharedApplication] registerForRemoteNotifications];
        [[UIApplication sharedApplication] registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeBadge|UIUserNotificationTypeSound|UIUserNotificationTypeAlert categories:nil]];
    }
    
    //判断是否由远程消息通知触发应用程序启动
    if (launchOptions) {
        //获取应用程序消息通知标记数（即小红圈中的数字）
        NSInteger badge = [UIApplication sharedApplication].applicationIconBadgeNumber;
        if (badge>0) {
            //如果应用程序消息通知标记数（即小红圈中的数字）大于0，清除标记。
            badge--;
            //清除标记。清除小红圈中数字，小红圈中数字为0，小红圈才会消除。
            [UIApplication sharedApplication].applicationIconBadgeNumber = badge;
            NSDictionary *pushInfo = [launchOptions objectForKey:@"UIApplicationLaunchOptionsRemoteNotificationKey"];
            //获取推送详情
            NSString *pushString = [NSString stringWithFormat:@"%@",[pushInfo  objectForKey:@"aps"]];
            UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"finish Loaunch" message:pushString delegate:nil cancelButtonTitle:@"cancel" otherButtonTitles:nil];
            [alert show];
        }
    }
    return YES;
}

- (void)application:(UIApplication *)app didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
    [self upDateDeviceToken:deviceToken];
    [[NSUserDefaults standardUserDefaults]setObject:deviceToken forKey:@"deviceToken"];
}

- (void)application:(UIApplication *)app didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
    NSString *error_str = [NSString stringWithFormat: @"%@", error];
    NSLog(@"Failed to get token, error:%@", error_str);
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    //接收到消息推送
    [UIApplication sharedApplication].applicationIconBadgeNumber=0;
    for (id key in userInfo) {
        NSLog(@"key: %@, value: %@", key, [userInfo objectForKey:key]);
    }
    /* eg.
     key: aps, value: {*-
     alert = "\U8fd9\U662f\U4e00\U6761\U6d4b\U8bd5\U4fe1\U606f";
     badge = 1;
     sound = default;
     }
     */
//    UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"remote notification" message:userInfo[@"aps"][@"alert"] delegate:nil cancelButtonTitle:@"cancel" otherButtonTitles:nil];
//    [alert show];
}

-(void)applicationWillEnterForeground:(UIApplication *)application
{
    NSData * deviceToken = [[NSUserDefaults standardUserDefaults]objectForKey:@"deviceToken"];
    if (deviceToken!=nil) {
        //NSLog(@"----------%@",deviceToken);
        [self upDateDeviceToken:deviceToken];
    }
    
}


-(void)upDateDeviceToken:(NSData*)deviceTokenString
{
    NSString * device = [[[NSString stringWithFormat:@"%@",deviceTokenString]stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"<>"]]stringByReplacingOccurrencesOfString:@" " withString:@""];
    //    NSLog(@"%@",device);
    NSString *adId = [[[ASIdentifierManager sharedManager] advertisingIdentifier] UUIDString];
    //    NSLog(@"%@",adId);
    //这里应将device token发送到服务器端
    NSString * param = [NSString stringWithFormat:@"&deviceToken=%@&deviceId=%@",device,adId];
    NSString * urlStr =[NSString stringWithFormat:@"%@%@%@",Severpath,UpdateDeviceToken,param];//需要修改
//    NSLog(@"%@",urlStr);
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer.acceptableContentTypes=[NSSet setWithObjects:@"text/html",@"application/json",@"text/plain",@"text/json", nil];
    [manager GET:urlStr parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSLog(@"%@",responseObject);
        NSDictionary * imgList = responseObject;
        if ([imgList[@"r"]intValue]==200)//需要修改
        {
            //            UIAlertView * alert = [[UIAlertView alloc]initWithTitle:[NSString stringWithFormat:@"请求成功,%@",imgList[@"code"]] message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
            //            [alert show];//需要修改
            
            
        }else{
            UIAlertView * alert = [[UIAlertView alloc]initWithTitle:[NSString stringWithFormat:@"请求失败,%@",imgList[@"r"]] message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
            [alert show];//需要修改
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:[NSString stringWithFormat:@"%@%@",@"请求失败,请检查网络。",error.localizedDescription] message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
        [alert show];//需要修改
    }];
}

@end
