//
//  ViewController.m
//  MobilSeverPush
//
//  Created by bean on 2017/1/10.
//  Copyright © 2017年 com.xile. All rights reserved.
//

#import "ViewController.h"

#import "HandleViewController.h"

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic,assign)CGFloat screenWidth;
@property(nonatomic,assign)CGFloat screenHeight;

@property(nonatomic,assign)CGFloat customScreenWidth1;
@property(nonatomic,assign)CGFloat customScreenHeight1;

@property(nonatomic,strong)UILabel * noticeLB;

@property(nonatomic,strong)UITableView * tableView;
@property(nonatomic,strong)NSMutableArray * imgOderArray;
@property(nonatomic,strong)UIButton * refreshBtn;




@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _screenWidth = [UIScreen mainScreen].bounds.size.width;
    _screenHeight = [UIScreen mainScreen].bounds.size.height;
    
    _noticeLB = [[UILabel alloc]initWithFrame:CGRectMake(0, 15, _screenWidth, 15)];
    _noticeLB.textAlignment = 1;
    _noticeLB.text = @"滑动选择需要处理的订单列表";
    [self.view addSubview:_noticeLB];
    
    
    _imgOderArray = [NSMutableArray array];
    
    
    _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_noticeLB.frame)+15, _screenWidth, _screenHeight-CGRectGetMaxY(_noticeLB.frame)-45-50) style:UITableViewStylePlain];
    _tableView.tableFooterView = [[UIView alloc]init];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    [self.view addSubview:_tableView];
    
    
    _refreshBtn = [[UIButton alloc]initWithFrame:CGRectMake(_screenWidth/2-50, CGRectGetMaxY(_tableView.frame)+10, 100, 30)];
    _refreshBtn.backgroundColor = [UIColor redColor];
    [_refreshBtn setTitle:@"刷新" forState:UIControlStateNormal];
    [_refreshBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    _refreshBtn.layer.cornerRadius = 5;
    _refreshBtn.clipsToBounds = YES;
    [_refreshBtn addTarget:self action:@selector(refreshData) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_refreshBtn];
    
    
    
    [self getOrderPicList];
    
}

-(void)refreshData
{
    NSLog(@"刷新数据");
    [self getOrderPicList];
}


-(void)getOrderPicList
{
    NSString * urlStr =[NSString stringWithFormat:@"%@%@",Severpath,GetImgList];//需要修改
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer.acceptableContentTypes=[NSSet setWithObjects:@"text/html",@"application/json",@"text/plain",@"text/json", nil];
    [manager GET:urlStr parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSDictionary * dataDic = responseObject;
        NSLog(@"%@",dataDic);
        if ([dataDic[@"r"]intValue]==200)//需要修改
        {
            
            NSLog(@"获得的图片下载地址数据：：%@",dataDic);
            if (_imgOderArray.count!=0) {
                [_imgOderArray removeAllObjects];
            }
            
            NSArray * imgArray = dataDic[@"data"];
            for (NSDictionary * imgListDic in imgArray) {
                [_imgOderArray addObject:imgListDic];
            }
            [_tableView reloadData];
            
        }else{
            UIAlertView * alert = [[UIAlertView alloc]initWithTitle:[NSString stringWithFormat:@"请求失败,%@",dataDic[@"code"]] message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
            [alert show];//需要修改
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        NSLog(@"%@",error.description);
        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"请求失败,请检查网络。" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
        [alert show];//需要修改
    }];
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _imgOderArray.count;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * idStr = @"xunbao";
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:idStr];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:idStr];
    }
    cell.textLabel.text = [_imgOderArray[indexPath.row]objectForKey:@"orderNum"];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(nonnull NSIndexPath *)indexPath
{
    HandleViewController * handle = [[HandleViewController alloc]init];
    NSLog(@"%@",_imgOderArray[indexPath.row]);
    handle.orderString = [_imgOderArray[indexPath.row]objectForKey:@"orderNum"];
    handle.urlArray = [_imgOderArray[indexPath.row]objectForKey:@"names"];
    handle.customSscreenWidth = [[_imgOderArray[indexPath.row]objectForKey:@"width"]floatValue];
    handle.customSscreenHeight = [[_imgOderArray[indexPath.row]objectForKey:@"height"]floatValue];
    [self presentViewController:handle animated:YES completion:nil];
}




//不支持旋转
-(BOOL)shouldAutorotate{
    return NO;
}
@end
