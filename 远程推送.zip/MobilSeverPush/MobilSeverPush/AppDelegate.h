//
//  AppDelegate.h
//  MobilSeverPush
//
//  Created by bean on 2017/1/10.
//  Copyright © 2017年 com.xile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

