//
//  HandleViewController.m
//  MobilSeverPush
//
//  Created by bean on 2017/1/10.
//  Copyright © 2017年 com.xile. All rights reserved.
//

#import "HandleViewController.h"

@interface HandleViewController ()<UIScrollViewDelegate,UIAlertViewDelegate>

@property(nonatomic,assign)CGFloat severScreenWidth;
@property(nonatomic,assign)CGFloat severScreenHeight;

@property(nonatomic,assign)CGFloat widthScale;
@property(nonatomic,assign)CGFloat heightScale;

@property(nonatomic,strong)UIPageControl * pageControl;
@property(nonatomic,strong)UIScrollView * scrollView;

@property(nonatomic,assign)CGPoint tapPoint;
@property(nonatomic,assign)NSInteger page;

@property(nonatomic,strong)UIActivityIndicatorView * activView;


@end

@implementation HandleViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _severScreenWidth = [UIScreen mainScreen].bounds.size.width;
    _severScreenHeight = [UIScreen mainScreen].bounds.size.height;

    _widthScale = _customSscreenWidth/_severScreenWidth;
    _heightScale = _customSscreenHeight/_severScreenHeight;
    
    [self creatUI];
}


-(void)creatUI
{
    _scrollView = [[UIScrollView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    _scrollView.delegate = self;
    _scrollView.showsVerticalScrollIndicator = NO;
    _scrollView.showsHorizontalScrollIndicator = NO;
    _scrollView.pagingEnabled = YES;
    [self.view addSubview:_scrollView];
    
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapSomePoint:)];
    tap.numberOfTapsRequired = 1;
    tap.numberOfTouchesRequired = 1;
    [_scrollView addGestureRecognizer:tap];
    
    
    _pageControl = [[UIPageControl alloc]init];
    _pageControl.frame = CGRectMake(0, _severScreenHeight-30, _severScreenWidth, 30);
    _pageControl.currentPage = 0;
    _pageControl.pageIndicatorTintColor = [UIColor yellowColor];
    _pageControl.currentPageIndicatorTintColor = [UIColor redColor];
    [self.view addSubview:_pageControl];
    
    
    _activView = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    _activView.center = self.view.center;
    [self.view addSubview:_activView];
    
    [self showImgs];
}


-(void)showImgs
{
    for (int i = 0 ; i<_urlArray.count; i++)
    {
        UIImageView * image = [[UIImageView alloc]initWithFrame:CGRectMake(i*_severScreenWidth, 0, _severScreenWidth, _severScreenHeight)];
        [image sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",ImgDownLoadPath,_urlArray[i]]] placeholderImage:[UIImage imageNamed:@"1024.png"]];
        [_scrollView addSubview:image];
    }
    _scrollView.contentSize = CGSizeMake(_severScreenWidth*_urlArray.count, _severScreenHeight);
    _scrollView.contentOffset = CGPointZero;
    _pageControl.numberOfPages = _urlArray.count;
}


-(void)tapSomePoint:(UITapGestureRecognizer*)tapview
{
    _tapPoint = [tapview locationInView:self.view];
    UIAlertView * alert = [[UIAlertView alloc]initWithTitle:[NSString stringWithFormat:@"是否提交点击的区域?"] message:nil delegate:self cancelButtonTitle:@"提交" otherButtonTitles:@"重新选择",@"不处理并返回",nil];
    [alert show];
    
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex) {
        case 0:
        {
            [self upDataPointWithOrderNum];
        }
            break;
        case 1:
        {
            NSLog(@"重新选");
        }
            break;
        case 2:
        {
            NSLog(@"不处理");
            [self dismissViewControllerAnimated:YES completion:nil];
        }
            break;

        default:
            break;
    }
}


-(void)upDataPointWithOrderNum
{
    //开始动画
    [_activView startAnimating];
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    _scrollView.userInteractionEnabled = NO;
    NSString * imgName = _urlArray[_page];
    float tapXNum = _tapPoint.x * _widthScale;
    float tapYNum = _tapPoint.y * _heightScale;
    NSLog(@"点击的X：%f   X的比例：%f   点击的Y：%f   Y的比例：%f",_tapPoint.x,_widthScale,_tapPoint.y,_heightScale);
    NSString * tapX = [NSString stringWithFormat:@"%.2f",tapXNum];
    NSString * tapY = [NSString stringWithFormat:@"%.2f",tapYNum];
    NSString * param = [NSString stringWithFormat:@"name=%@&x=%@&y=%@",imgName,tapX,tapY];
    NSString * urlStr = [NSString stringWithFormat:@"%@%@%@",Severpath,UpdateTouchPoint,param];
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer.acceptableContentTypes=[NSSet setWithObjects:@"text/html",@"application/json",@"text/plain",@"text/json", nil];
    [manager GET:urlStr parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSDictionary * imgDataDic = responseObject;
        if ([imgDataDic[@"r"]intValue]==200)
        {
            [self statueStop];
            [self dismissViewControllerAnimated:YES completion:nil];
        }
        else
        {
            [self statueStop];
            UIAlertView * alert = [[UIAlertView alloc]initWithTitle:[NSString stringWithFormat:@"提交失败,%@",imgDataDic[@"code"]] message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
            [alert show];
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [self statueStop];
        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"提交失败,请检查网络。" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
        [alert show];
    }];
}



#pragma mark **UIScrollViewDelegate**
//结束减速的时候调用  然后计算偏移量
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    _page = scrollView.contentOffset.x/_severScreenWidth;
    _pageControl.currentPage = _page;
}

-(void)statueStop
{
    _scrollView.userInteractionEnabled = YES;
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    [_activView stopAnimating];
}
//不支持旋转
-(BOOL)shouldAutorotate{
    return NO;
}

@end
